<?php
/**
 * Silence is golden.
 *
 * @package Frontend Dashboard
 */
